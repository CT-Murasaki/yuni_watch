'use strict';

function getDefaultExportFromCjs(x) {
  return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}
var main$1 = {};
main$1.main = void 0;
function main(param) {
  g.game.pushScene(makescene());
}
function makescene(param) {
  var mainList = [];
  var imagenum = 72;
  for (var i = 1; i <= imagenum; i++) {
    mainList.push("main" + i);
  }
  var scene = new g.Scene({
    game: g.game,
    // このシーンで利用するアセットのIDを列挙し、シーンに通知します
    assetIds: mainList
  });

  // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います
  g.game.vars.gameState = {
    score: 0
  };
  scene.onLoad.add(function () {
    // ここからゲーム内容を記述します

    var font = new g.DynamicFont({
      game: g.game,
      fontFamily: "sans-serif",
      size: 48
    });
    // スコア表示用のラベル
    var scoreLabel = new g.Label({
      scene: scene,
      text: "SCORE: 0",
      font: font,
      fontSize: font.size / 2,
      textColor: "black"
    });
    scene.append(scoreLabel);
    var closeingLabel = new g.Label({
      scene: scene,
      text: "口が閉じた回数: 0",
      font: font,
      fontSize: font.size / 2,
      anchorY: -1,
      textColor: "black"
    });
    scene.append(closeingLabel);
    var score = 0;
    var closeingcnt = 0;
    var images = new g.FrameSprite({
      scene: scene,
      src: scene.assets["main" + 1],
      x: g.game.width / 3,
      opacity: 1
    });
    scene.append(images);
    images.invalidate();
    var gametime = 0;
    var gameimage = 0;
    var correction = false;
    // ■■■■■■■■■■■■　 開始処理　　■■■■■■■■■■■■
    scene.onUpdate.add(function () {
      //時間経過
      gametime += 1 / g.game.fps;
      if (gametime <= 15) {
        gameimage = g.game.random.get(1, imagenum);
        images.src = scene.assets["main" + gameimage];
        images.invalidate();
        switch (gameimage) {
          case 68:
            score += g.game.random.get(1, 10000);
            closeingcnt += 1;
            break;
          case 17:
            score += 10000;
            closeingcnt += 1;
            break;
          case 35:
            score += 10000;
            break;
          case 72:
            score += 50000;
            closeingcnt += 1;
            break;
          case 69:
            break;
          default:
            score += g.game.random.get(1, 10000);
        }
        scoreLabel.text = "SCORE: " + score;
        scoreLabel.invalidate();
        closeingLabel.text = "口が閉じた回数: " + closeingcnt;
        closeingLabel.invalidate();
      } else if (correction == false) {
        scoreLabel.hide();
        closeingLabel.hide();
        images.hide();
        var scorevar = Math.floor(score * (1 + 0.1 * closeingcnt));
        g.game.vars.gameState.score = scorevar;
        console.log(g.game.vars.gameState.score);
        correction = true;
      }
    });
  });
  return scene;
}
main$1.main = main;
var main_1 = main$1;
var _bootstrap = function _bootstrap(originalParam) {
  var param = {};
  Object.keys(originalParam).forEach(function (key) {
    param[key] = originalParam[key];
  });
  // セッションパラメーター
  param.sessionParameter = {};
  // コンテンツが動作している環境がRPGアツマール上かどうか
  param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined";
  // 乱数生成器
  param.random = g.game.random;
  var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
  var scene = new g.Scene({
    game: g.game
  });
  // セッションパラメーターを受け取ってゲームを開始します
  scene.onMessage.add(function (msg) {
    if (msg.data && msg.data.type === "start" && msg.data.parameters) {
      param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
      if (msg.data.parameters.randomSeed != null) {
        param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
      }
      g.game.popScene();
      main_1.main(param);
    }
  });
  scene.onLoad.add(function () {
    var currentTickCount = 0;
    scene.onUpdate.add(function () {
      currentTickCount++;
      // 待ち時間を超えた場合はゲームを開始します
      if (currentTickCount > limitTickToWait) {
        g.game.popScene();
        main_1.main(param);
      }
    });
  });
  g.game.pushScene(scene);
};
var _bootstrap$1 = /*@__PURE__*/getDefaultExportFromCjs(_bootstrap);
module.exports = _bootstrap$1;