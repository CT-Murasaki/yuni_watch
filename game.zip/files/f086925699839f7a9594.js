function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }
          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }
        return n[i].exports;
      }
      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
      return o;
    }
    return r;
  }()({
    1: [function (require, module, exports) {
      var main_1 = require("./main");
      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        });
        // セッションパラメーター
        param.sessionParameter = {};
        // コンテンツが動作している環境がRPGアツマール上かどうか
        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined";
        // 乱数生成器
        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
        var scene = new g.Scene({
          game: g.game
        });
        // セッションパラメーターを受け取ってゲームを開始します
        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }
            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++;
            // 待ち時間を超えた場合はゲームを開始します
            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      exports.main = void 0;
      function main(param) {
        g.game.pushScene(makescene(param));
      }
      function makescene(param) {
        var mainList = [];
        var imagenum = 67;
        for (var i = 1; i <= imagenum; i++) {
          mainList.push("main" + i);
        }
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: mainList
        });

        // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います
        g.game.vars.gameState = {
          score: 0
        };
        scene.onLoad.add(function () {
          // ここからゲーム内容を記述します

          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 48
          });
          // スコア表示用のラベル
          var scoreLabel = new g.Label({
            scene: scene,
            text: "SCORE: 0",
            font: font,
            fontSize: font.size / 2,
            textColor: "white"
          });
          scene.append(scoreLabel);
          var closeingLabel = new g.Label({
            scene: scene,
            text: "口が閉じた回数: 0",
            font: font,
            fontSize: font.size / 2,
            anchorY: -1,
            textColor: "white"
          });
          scene.append(closeingLabel);
          var score = 0;
          var closeingcnt = 0;
          var images = [];
          for (var _i = 1; _i <= imagenum; _i++) {
            images[_i] = new g.FrameSprite({
              scene: scene,
              src: scene.assets["main" + _i],
              x: g.game.width / 3,
              opacity: 1,
              hidden: true
            });
            scene.append(images[_i]);
          }
          var gametime = 0;
          var gameimage = 0;
          var correction = false;
          // ■■■■■■■■■■■■　 開始処理　　■■■■■■■■■■■■
          scene.onUpdate.add(function () {
            //時間経過
            gametime += 1 / g.game.fps;
            if (gametime <= 15) {
              gameimage = g.game.random.get(1, imagenum);
              images[gameimage].show();
              switch (gameimage) {
                case (1, 10, 42, 52):
                  score += g.game.random.get(1, 10000);
                  closeingcnt += 1;
                  break;
                case 17:
                  score += 10000;
                  closeingcnt += 1;
                  break;
                case (13, 32, 35):
                  score += 10000;
                  break;
                case (15, 36):
                  break;
                default:
                  score += g.game.random.get(1, 10000);
              }
              scoreLabel.text = "SCORE: " + score;
              scoreLabel.invalidate();
              closeingLabel.text = "口が閉じた回数: " + closeingcnt;
              closeingLabel.invalidate();
              for (var _i2 = 1; _i2 <= imagenum; _i2++) {
                if (gameimage != _i2) {
                  images[_i2].hide();
                }
              }
            } else {
              scoreLabel.hide();
              closeingLabel.hide();
              for (var _i3 = 1; _i3 <= imagenum; _i3++) {
                images[_i3].hide();
              }
              if (correction == false) {
                var scorevar = Math.floor(score * (1 + 0.01 * closeingcnt));
                for (var _i4 = 1; _i4 <= 5; _i4++) {
                  g.game.vars.gameState.score = scorevar;
                }
                correction = true;
              }
            }
          });
        });
        return scene;
      }
      exports.main = main;
    }, {}]
  }, {}, [1])(1);
});