function _typeof(o) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) { return typeof o; } : function (o) { return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o; }, _typeof(o); }
(function (f) {
  if ((typeof exports === "undefined" ? "undefined" : _typeof(exports)) === "object" && typeof module !== "undefined") {
    module.exports = f();
  } else if (typeof define === "function" && define.amd) {
    define([], f);
  } else {
    var g;
    if (typeof window !== "undefined") {
      g = window;
    } else if (typeof global !== "undefined") {
      g = global;
    } else if (typeof self !== "undefined") {
      g = self;
    } else {
      g = this;
    }
    g.aez_bundle_main = f();
  }
})(function () {
  var define, module, exports;
  return function () {
    function r(e, n, t) {
      function o(i, f) {
        if (!n[i]) {
          if (!e[i]) {
            var c = "function" == typeof require && require;
            if (!f && c) return c(i, !0);
            if (u) return u(i, !0);
            var a = new Error("Cannot find module '" + i + "'");
            throw a.code = "MODULE_NOT_FOUND", a;
          }
          var p = n[i] = {
            exports: {}
          };
          e[i][0].call(p.exports, function (r) {
            var n = e[i][1][r];
            return o(n || r);
          }, p, p.exports, r, e, n, t);
        }
        return n[i].exports;
      }
      for (var u = "function" == typeof require && require, i = 0; i < t.length; i++) o(t[i]);
      return o;
    }
    return r;
  }()({
    1: [function (require, module, exports) {
      var main_1 = require("./main");
      module.exports = function (originalParam) {
        var param = {};
        Object.keys(originalParam).forEach(function (key) {
          param[key] = originalParam[key];
        });
        // セッションパラメーター
        param.sessionParameter = {};
        // コンテンツが動作している環境がRPGアツマール上かどうか
        param.isAtsumaru = typeof window !== "undefined" && typeof window.RPGAtsumaru !== "undefined";
        // 乱数生成器
        param.random = g.game.random;
        var limitTickToWait = 3; // セッションパラメーターが来るまでに待つtick数
        var scene = new g.Scene({
          game: g.game
        });
        // セッションパラメーターを受け取ってゲームを開始します
        scene.onMessage.add(function (msg) {
          if (msg.data && msg.data.type === "start" && msg.data.parameters) {
            param.sessionParameter = msg.data.parameters; // sessionParameterフィールドを追加
            if (msg.data.parameters.randomSeed != null) {
              param.random = new g.XorshiftRandomGenerator(msg.data.parameters.randomSeed);
            }
            g.game.popScene();
            main_1.main(param);
          }
        });
        scene.onLoad.add(function () {
          var currentTickCount = 0;
          scene.onUpdate.add(function () {
            currentTickCount++;
            // 待ち時間を超えた場合はゲームを開始します
            if (currentTickCount > limitTickToWait) {
              g.game.popScene();
              main_1.main(param);
            }
          });
        });
        g.game.pushScene(scene);
      };
    }, {
      "./main": 2
    }],
    2: [function (require, module, exports) {
      //■■■■■■■■■■■■　 ここまでコピペ用 　■■■■■■■■■■■■

      exports.main = void 0;
      function main(param) {
        g.game.pushScene(makescene(param));
      }
      function makescene(param) {
        var scene = new g.Scene({
          game: g.game,
          // このシーンで利用するアセットのIDを列挙し、シーンに通知します
          assetIds: ["main1", "main2", "main3", "main4", "main5", "main6", "main7", "main8", "main9", "main10", "main11", "main12", "main13", "main14", "main15", "main16", "main17", "main18", "main19", "main20", "main21", "main22", "main23", "main24", "main25", "main26", "main27", "main28", "main29", "main30", "main31", "main32", "main33", "main34", "main35", "main36", "main37", "main38", "main39", "main40", "main41", "main42", "main43", "main44", "main45", "main46", "main47", "main48", "main49", "main50", "main51", "main52", "main53", "main54", "main55", "main56", "main57", "main58", "main59", "main60", "main61", "main62", "main63", "main64", "main65", "main66", "main67", "main68", "main69", "main70", "main71", "main72", "main73", "main74", "main75", "main76", "main77", "main78", "main79", "main80", "main81", "main82", "main83", "main84", "main85", "main86", "main87", "main88", "main89", "main90", "main91", "main92", "main93", "main94", "main95", "main96", "main97", "main98", "main99", "main100", "main101", "main102", "main103", "main104", "main105", "main106", "main107", "main108", "main109", "main110", "main111", "main112", "main113", "main114", "main115", "main116", "main117", "main118", "main119", "main120", "main121", "main122", "main123", "main124", "main125", "main126",
          //音声ファイルはhttps://github.com/akashic-contents　CC BY 2.1 JP　DWANGO Co., Ltd.
          "se_finish"]
        });

        // 市場コンテンツのランキングモードでは、g.game.vars.gameState.score の値をスコアとして扱います
        g.game.vars.gameState = {
          score: 0
        };
        scene.onLoad.add(function () {
          // ここからゲーム内容を記述します

          var font = new g.DynamicFont({
            game: g.game,
            fontFamily: "sans-serif",
            size: 48
          });
          // スコア表示用のラベル
          var scoreLabel = new g.Label({
            scene: scene,
            text: "SCORE: 0",
            font: font,
            fontSize: font.size / 2,
            textColor: "white"
          });
          scene.append(scoreLabel);
          var closeingLabel = new g.Label({
            scene: scene,
            text: "口が閉じた回数: 0",
            font: font,
            fontSize: font.size / 2,
            anchorY: -1,
            textColor: "white"
          });
          scene.append(closeingLabel);
          var imagenum = 126;
          var closeingcnt = 0;
          var images = [];
          for (var i = 1; i <= imagenum; i++) {
            images[i] = new g.FrameSprite({
              scene: scene,
              src: scene.assets["main" + i],
              x: g.game.width / 3,
              opacity: 0
            });
            scene.append(images[i]);
          }
          var gametime = 0;
          var gameimage = 0;
          var correction = false;
          // ■■■■■■■■■■■■　 開始処理　　■■■■■■■■■■■■
          scene.onUpdate.add(function () {
            //時間経過
            gametime += 1 / g.game.fps;
            if (gametime <= 15) {
              gameimage = g.game.random.get(1, imagenum);
              images[gameimage].opacity = 1;
              images[gameimage].invalidate();
              switch (gameimage) {
                case 3:
                case 26:
                case 60:
                case 61:
                case 83:
                case 87:
                case 89:
                case 99:
                case 114:
                case 120:
                case 122:
                case 123:
                case 125:
                  g.game.vars.gameState.score += g.game.random.get(0, 10000);
                  closeingcnt += 1;
                  break;
                case 74:
                case 100:
                  g.game.vars.gameState.score += 10000;
                  break;
                case 104:
                  g.game.vars.gameState.score += 100000;
                  closeingcnt += 1;
                  break;
                default:
                  g.game.vars.gameState.score += g.game.random.get(0, 10000);
              }
              scoreLabel.text = "SCORE: " + g.game.vars.gameState.score;
              scoreLabel.invalidate();
              closeingLabel.text = "口が閉じた回数: " + closeingcnt;
              closeingLabel.invalidate();
              for (var _i = 1; _i <= imagenum; _i++) {
                if (gameimage != _i) {
                  images[_i].opacity = 0;
                  images[_i].invalidate();
                }
              }
            } else {
              scoreLabel.opacity = 0;
              scoreLabel.invalidate();
              closeingLabel.opacity = 0;
              closeingLabel.invalidate();
              for (var _i2 = 1; _i2 <= imagenum; _i2++) {
                images[_i2].opacity = 0;
                images[_i2].invalidate();
              }
              if (correction == false) {
                g.game.vars.gameState.score = Math.ceil(g.game.vars.gameState.score + g.game.vars.gameState.score * closeingcnt * 0.01);
                correction = true;
              }
            }
          });
          // ■■■■■■■■■■■■　 終了処理　　■■■■■■■■■■■■
          // ここまでゲーム内容を記述します
        });
        return scene;
      }
      exports.main = main;
    }, {}]
  }, {}, [1])(1);
});